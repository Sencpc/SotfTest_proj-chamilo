# Pembagian Tugas Testing Chamilo Website

## 👤 Orang 1

- Navbar & Footer (Komponen Umum)
- Homepage: https://chamilo.org/en/
- Demo: https://chamilo.org/en/demo/

## 👤 Orang 2

- Forum: https://chamilo.org/en/forum/
- Download: https://chamilo.org/en/download/
- Global Search functionality

## 👤 Orang 3

- Contact: https://chamilo.org/en/contact/
- Official Providers: https://chamilo.org/en/providers/
- Chamilo Association: https://chamilo.org/en/chamilo-2/

## 👤 Orang 4

- Training: https://chamilo.org/en/training/
- Contribute: https://chamilo.org/en/contribute/
- Events: https://chamilo.org/en/eventos/

---

**File lengkap:** `CekList.md`  
**Browser:** Brave  
**Language:** English (/en/) only
